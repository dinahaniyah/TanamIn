		$(function(){
		    $("#tanggal").datepicker({
			format:'dd/mm/yyyy'
		    });
                });